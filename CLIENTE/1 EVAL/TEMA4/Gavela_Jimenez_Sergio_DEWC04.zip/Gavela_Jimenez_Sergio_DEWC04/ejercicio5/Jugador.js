export class Jugador{
     
    constructor(){
        this.power = 1
    }



    increasePower(){
        this.power ++
    }

    showPower(){
        alert(`tu Fuerza es ${this.power}`)
    }

}

