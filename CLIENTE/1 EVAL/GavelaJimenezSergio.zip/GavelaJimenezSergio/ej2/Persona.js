
export class Persona{

constructor(nombre,apellidos,email,contraseña){
    this.nombre = nombre;
    this.apellidos = apellidos;
    this.email = email;
    this.contraseña = contraseña;
}


}