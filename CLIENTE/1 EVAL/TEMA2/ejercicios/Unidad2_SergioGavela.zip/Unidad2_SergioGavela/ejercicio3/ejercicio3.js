let operacion1 = (10 ==10);
let operacion2 = (10 === 10);
let operacion3 = (10 === 10.0);
let operacion4 = ("Laura" == "laura");
let operacion5 = ("Laura" > "laura");
let operacion6 = ("Laura" < "laura");
let operacion7 = ("123" == 123);
let operacion8 = ("123" === 123);





alert("La operacion 10 == 10 es "+operacion1);
alert("La operacion 10 === 10 es " + operacion2);
alert("La operacion 10 === 10.0 es " + operacion3);
alert("La operacion Laura == laura es" + operacion4);
alert( "La operacion Laura > laura es" + operacion5);
alert("La operacion Laura < laura es" + operacion6);
alert("La operacion  es '123' == 123 es" + operacion7);
alert("La operacion  es '123' === 123 es" + operacion8);