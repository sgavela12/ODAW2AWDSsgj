let frase1 = "hola que tal";
let frase2 = "yo bien y tu";
let edad = 12;
let añoNacimiento = 34;

alert('Buenas tardes');
alert("Sergio \n Gavela \n Jimenez");
alert(edad+añoNacimiento);
alert(frase1+frase2+edad+añoNacimiento)