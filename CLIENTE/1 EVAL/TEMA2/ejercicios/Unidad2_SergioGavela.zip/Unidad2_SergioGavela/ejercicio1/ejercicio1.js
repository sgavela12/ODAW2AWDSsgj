
let entero = 1357;
let decimal = 135.7;
let cientifico = 135e7;
let octal =  0o1357;
let hexadecimal = 0X1357;

console.log( "Numero entero "+ entero);
console.log( "Numero entero "+ decimal);
console.log( "Numero entero "+ cientifico);
console.log( "Numero entero "+ octal);
console.log( "Numero entero "+ hexadecimal);