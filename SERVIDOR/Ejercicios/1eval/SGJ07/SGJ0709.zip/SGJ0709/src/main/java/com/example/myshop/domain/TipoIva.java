package com.example.myshop.domain;

public enum TipoIva {
    SUPERREDUCIDO, REDUCIDO, NORMAL
};
