package com.example.myshop.domain;

public enum TipoContacto {
    QUEJA, CONSULTA, OTROS
};
