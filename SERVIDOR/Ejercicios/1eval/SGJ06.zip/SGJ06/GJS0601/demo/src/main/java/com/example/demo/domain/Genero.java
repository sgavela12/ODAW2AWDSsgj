package com.example.demo.domain;

public enum Genero {
  MASCULINO, FEMENINO, OTROS ;
}
