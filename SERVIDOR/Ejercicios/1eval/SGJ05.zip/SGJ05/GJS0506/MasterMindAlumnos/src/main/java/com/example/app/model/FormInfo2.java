package com.example.app.model;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class FormInfo2 {
    private int numIntentos;
    private int cadenaSize;
}
