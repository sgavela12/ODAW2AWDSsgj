package com.example.app.model;

public enum EstadoJuego {
    JUGANDO, GANO, PERDIO
    //enum limita el EstadoJuego a los tres valores de la línea superior
}
