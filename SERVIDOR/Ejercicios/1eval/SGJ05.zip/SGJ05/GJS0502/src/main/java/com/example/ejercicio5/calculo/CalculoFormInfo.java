package com.example.ejercicio5.calculo;

public class CalculoFormInfo {
    private int numero;

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    
    
}
