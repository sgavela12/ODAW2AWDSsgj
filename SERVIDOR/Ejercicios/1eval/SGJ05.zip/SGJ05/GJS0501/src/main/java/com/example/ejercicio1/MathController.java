package com.example.ejercicio1;

import org.springframework.stereotype.Controller;

@Controller
public class MathController {

    
   
    
}
