package com.odaw2a.glc1003.domain;

public enum Genero {
    Masculino,
    Femenino,
    Otro
}
