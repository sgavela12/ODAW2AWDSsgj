package com.example.xbc0701;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Xbc0701ApplicationTests {

	@Test
	void contextLoads() {
	}

}
