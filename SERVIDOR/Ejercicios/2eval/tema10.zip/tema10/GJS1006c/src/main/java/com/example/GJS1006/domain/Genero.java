package com.example.GJS1006.domain;

public enum Genero {MASCULINO, FEMENINO, OTROS};
