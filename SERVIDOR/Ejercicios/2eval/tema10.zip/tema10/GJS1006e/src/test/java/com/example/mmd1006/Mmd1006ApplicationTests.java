package com.example.mmd1006;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Mmd1006ApplicationTests {

	@Test
	void contextLoads() {
	}

}
