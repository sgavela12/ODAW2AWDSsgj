package com.odaw2a.GJS1003.domain;

public enum Genero {
    Masculino,
    Femenino,
    Otro
}
