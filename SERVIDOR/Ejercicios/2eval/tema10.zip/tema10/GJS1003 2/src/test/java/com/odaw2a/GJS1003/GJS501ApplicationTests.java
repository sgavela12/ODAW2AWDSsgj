package com.odaw2a.GJS1003;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GJS501ApplicationTests {

	@Test
	void contextLoads() {
	}

}
