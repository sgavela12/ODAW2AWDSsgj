package com.example.dmm0601;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GJS0601ApplicationTests {

	@Test
	void contextLoads() {
	}

}
