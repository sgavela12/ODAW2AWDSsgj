package com.example.GJS0601.Domain;

    public enum Genero { MASCULINO, FEMENINO, OTROS };
